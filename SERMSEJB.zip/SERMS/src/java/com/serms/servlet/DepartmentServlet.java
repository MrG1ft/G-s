package com.serms.servlet;

import com.serms.model.DepartmentFacade;
import com.serms.model.Department;

import javax.ejb.EJB;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;
import java.io.IOException;
import java.util.List;

@WebServlet("/departments")
public class DepartmentServlet extends HttpServlet {

    @EJB
    private DepartmentFacade departmentFacade;

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        List<Department> departments = departmentFacade.findAll();

        request.setAttribute("departments", departments);
        request.getRequestDispatcher("/WEB-INF/departments.jsp").forward(request, response);
    }
}
