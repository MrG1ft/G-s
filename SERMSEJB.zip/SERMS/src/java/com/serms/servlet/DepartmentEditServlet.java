package com.serms.servlet;

import com.serms.model.DepartmentFacade;
import com.serms.model.Department;

import javax.ejb.EJB;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;
import java.io.IOException;

@WebServlet("/department/edit")
public class DepartmentEditServlet extends HttpServlet {

    @EJB
    private DepartmentFacade departmentFacade;

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        Long id = Long.parseLong(request.getParameter("id"));
        Department department = departmentFacade.find(id);

        request.setAttribute("department", department);
        request.getRequestDispatcher("/WEB-INF/department_edit.jsp").forward(request, response);
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        Long id = Long.parseLong(request.getParameter("id"));
        String name = request.getParameter("name");

        Department department = departmentFacade.find(id);
        if (department != null) {
            department.setName(name);
            departmentFacade.edit(department);
        }

        response.sendRedirect(request.getContextPath() + "/departments");
    }
}
