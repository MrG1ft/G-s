package com.serms.servlet;

import com.serms.model.ProjectFacade;
import com.serms.model.Project;

import javax.ejb.EJB;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;
import java.io.IOException;

@WebServlet("/project/delete")
public class ProjectDeleteServlet extends HttpServlet {

    @EJB
    private ProjectFacade projectFacade;

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        Long id = Long.parseLong(request.getParameter("id"));
        Project project = projectFacade.find(id);

        if (project != null) {
            projectFacade.remove(project);
        }

        response.sendRedirect(request.getContextPath() + "/projects");
    }
}
