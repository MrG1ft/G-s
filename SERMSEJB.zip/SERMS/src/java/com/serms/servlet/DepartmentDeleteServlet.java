package com.serms.servlet;

import com.serms.model.DepartmentFacade;
import com.serms.model.Department;

import javax.ejb.EJB;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;
import java.io.IOException;

@WebServlet("/department/delete")
public class DepartmentDeleteServlet extends HttpServlet {

    @EJB
    private DepartmentFacade departmentFacade;

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        Long id = Long.parseLong(request.getParameter("id"));
        Department department = departmentFacade.find(id);

        if (department != null) {
            departmentFacade.remove(department);
        }

        response.sendRedirect(request.getContextPath() + "/departments");
    }
}
