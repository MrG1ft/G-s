package com.serms.servlet;

import com.serms.model.Employee;
import com.serms.model.Department;
import com.serms.model.Project;
import com.serms.model.EmployeeFacade;
import com.serms.model.DepartmentFacade;
import com.serms.model.ProjectFacade;

import javax.ejb.EJB;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;
import java.io.IOException;
import java.util.List;

@WebServlet("/employee-create")
public class EmployeeCreateServlet extends HttpServlet {

    @EJB
    private EmployeeFacade employeeFacade;

    @EJB
    private DepartmentFacade departmentFacade;

    @EJB
    private ProjectFacade projectFacade;

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        List<Department> departments = departmentFacade.findAll();
        List<Project> projects = projectFacade.findAll();

        request.setAttribute("departments", departments);
        request.setAttribute("projects", projects);
        request.getRequestDispatcher("/WEB-INF/employee_create.jsp").forward(request, response);
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        String name = request.getParameter("name");
        String email = request.getParameter("email");
        String deptIdStr = request.getParameter("departmentId");
        String projIdStr = request.getParameter("projectId");

        String errorMessage = null;

        if (name == null || name.trim().isEmpty()) {
            errorMessage = "Name is required.";
        } else if (email == null || email.trim().isEmpty()) {
            errorMessage = "Email is required.";
        } else if (deptIdStr == null || projIdStr == null) {
            errorMessage = "Department and Project must be selected.";
        }

        if (errorMessage != null) {
            // Reload dropdown data and forward back with error message
            request.setAttribute("errorMessage", errorMessage);
            request.setAttribute("departments", departmentFacade.findAll());
            request.setAttribute("projects", projectFacade.findAll());

            // Pre-fill entered values so user doesn’t lose them
            request.setAttribute("name", name);
            request.setAttribute("email", email);
            request.setAttribute("selectedDepartmentId", deptIdStr);
            request.setAttribute("selectedProjectId", projIdStr);

            request.getRequestDispatcher("/WEB-INF/employee_create.jsp").forward(request, response);
            return;
        }

        Long departmentId = Long.parseLong(deptIdStr);
        Long projectId = Long.parseLong(projIdStr);

        Department department = departmentFacade.find(departmentId);
        Project project = projectFacade.find(projectId);

        Employee employee = new Employee();
        employee.setName(name);
        employee.setEmail(email);
        employee.setDepartment(department);
        employee.setProject(project);

        employeeFacade.create(employee);

        response.sendRedirect(request.getContextPath() + "/employees"); // Redirect to employee list
    }
}
