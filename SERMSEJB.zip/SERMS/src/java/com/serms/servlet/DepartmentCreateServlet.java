package com.serms.servlet;

import com.serms.model.DepartmentFacade;
import com.serms.model.Department;

import javax.ejb.EJB;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;
import java.io.IOException;

@WebServlet("/department/create")
public class DepartmentCreateServlet extends HttpServlet {

    @EJB
    private DepartmentFacade departmentFacade;

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        request.getRequestDispatcher("/WEB-INF/department_create.jsp").forward(request, response);
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        String name = request.getParameter("name");

        Department department = new Department();
        department.setName(name);

        departmentFacade.create(department);

        response.sendRedirect(request.getContextPath() + "/departments");
    }
}
