package com.serms.servlet;

import com.serms.model.EmployeeFacade;
import com.serms.model.Employee;

import javax.ejb.EJB;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;
import java.io.IOException;

@WebServlet("/employee/delete")
public class EmployeeDeleteServlet extends HttpServlet {

    @EJB
    private EmployeeFacade employeeFacade;

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        Long id = Long.parseLong(request.getParameter("id"));

        Employee employee = employeeFacade.find(id);
        if (employee != null) {
            employeeFacade.remove(employee);
        }

        response.sendRedirect(request.getContextPath() + "/employees");
    }
}
