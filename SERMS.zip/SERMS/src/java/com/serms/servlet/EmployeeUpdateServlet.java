package com.serms.servlet;

import com.serms.model.EmployeeFacade;
import com.serms.model.DepartmentFacade;
import com.serms.model.ProjectFacade;
import com.serms.model.Employee;
import com.serms.model.Department;
import com.serms.model.Project;

import javax.ejb.EJB;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;
import java.io.IOException;
import java.util.List;

@WebServlet("/employee/edit")
public class EmployeeUpdateServlet extends HttpServlet {

    @EJB
    private EmployeeFacade employeeFacade;

    @EJB
    private DepartmentFacade departmentFacade;

    @EJB
    private ProjectFacade projectFacade;

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        Long id = Long.parseLong(request.getParameter("id"));

        Employee employee = employeeFacade.find(id);
        List<Department> departments = departmentFacade.findAll();
        List<Project> projects = projectFacade.findAll();

        request.setAttribute("employee", employee);
        request.setAttribute("departments", departments);
        request.setAttribute("projects", projects);

        request.getRequestDispatcher("/WEB-INF/employee_edit.jsp").forward(request, response);
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        Long id = Long.parseLong(request.getParameter("id"));
        String name = request.getParameter("name");
        String email = request.getParameter("email");
        Long departmentId = Long.parseLong(request.getParameter("departmentId"));
        Long projectId = Long.parseLong(request.getParameter("projectId"));

        Employee employee = employeeFacade.find(id);
        employee.setName(name);
        employee.setEmail(email);
        employee.setDepartment(departmentFacade.find(departmentId));
        employee.setProject(projectFacade.find(projectId));

        employeeFacade.edit(employee);

        response.sendRedirect("employees");
    }
}

