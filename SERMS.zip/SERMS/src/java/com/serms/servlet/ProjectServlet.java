package com.serms.servlet;

import com.serms.model.ProjectFacade;
import com.serms.model.Project;

import javax.ejb.EJB;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;
import java.io.IOException;
import java.util.List;

@WebServlet("/projects")
public class ProjectServlet extends HttpServlet {

    @EJB
    private ProjectFacade projectFacade;

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        List<Project> projects = projectFacade.findAll();

        request.setAttribute("projects", projects);
        request.getRequestDispatcher("/WEB-INF/projects.jsp").forward(request, response);
    }
}
