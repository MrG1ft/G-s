package com.serms.servlet;

import com.serms.model.ProjectFacade;
import com.serms.model.Project;

import javax.ejb.EJB;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;
import java.io.IOException;

@WebServlet("/project/edit")
public class ProjectEditServlet extends HttpServlet {

    @EJB
    private ProjectFacade projectFacade;

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        Long id = Long.parseLong(request.getParameter("id"));
        Project project = projectFacade.find(id);

        request.setAttribute("project", project);
        request.getRequestDispatcher("/WEB-INF/project_edit.jsp").forward(request, response);
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        Long id = Long.parseLong(request.getParameter("id"));
        String title = request.getParameter("title");

        Project project = projectFacade.find(id);
        if (project != null) {
            project.setTitle(title);
            projectFacade.edit(project);
        }

        response.sendRedirect(request.getContextPath() + "/projects");
    }
}
