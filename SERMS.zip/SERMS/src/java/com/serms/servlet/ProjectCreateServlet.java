package com.serms.servlet;

import com.serms.model.ProjectFacade;
import com.serms.model.Project;

import javax.ejb.EJB;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;
import java.io.IOException;

@WebServlet("/project/create")
public class ProjectCreateServlet extends HttpServlet {

    @EJB
    private ProjectFacade projectFacade;

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        request.getRequestDispatcher("/WEB-INF/project_create.jsp").forward(request, response);
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        String title = request.getParameter("title");

        Project project = new Project();
        project.setTitle(title);

        projectFacade.create(project);

        response.sendRedirect(request.getContextPath() + "/projects");
    }
}
